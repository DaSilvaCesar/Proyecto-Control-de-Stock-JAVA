import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Empleado {
    private JTextField nombreBoton;
    private JTextField apellidoBoton;
    private JTextField FechaNaciBoton;
    private JTextField dniBoton;
    private JTextField direccionBoton;
    private JTextField puestoBoton;
    private JPanel empleadoPanel;
    private JButton registrarButton;
    private JTable table1;
    private JButton eliminarButton;
    private DefaultTableModel tablita;

    public Empleado() {
        // Inicializar el modelo de tabla
        tablita = new DefaultTableModel();
        tablita.addColumn("Nombre");
        tablita.addColumn("Apellido");
        tablita.addColumn("Fecha de Nacimiento");
        tablita.addColumn("DNI");
        tablita.addColumn("Dirección");
        tablita.addColumn("Puesto");

        // Configurar la tabla con el modelo
        table1.setModel(tablita);

        // Agregar listener al botón de registrar
        registrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obtener los valores de los campos de texto
                String nombre = nombreBoton.getText();
                String apellido = apellidoBoton.getText();
                String fechaNacimiento = FechaNaciBoton.getText();
                String dni = dniBoton.getText();
                String direccion = direccionBoton.getText();
                String puesto = puestoBoton.getText();

                // Agregar una nueva fila al modelo de tabla
                Object[] datos = new Object[]{nombre, apellido, fechaNacimiento, dni, direccion, puesto};
                tablita.addRow(datos);

                // Limpiar los campos de texto después de registrar el empleado
                nombreBoton.setText("");
                apellidoBoton.setText("");
                FechaNaciBoton.setText("");
                dniBoton.setText("");
                direccionBoton.setText("");
                puestoBoton.setText("");
            }
        });

        // Agregar listener al botón de eliminar
        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obtener la fila seleccionada
                int fila = table1.getSelectedRow();
                if (fila >= 0) {
                    // Eliminar la fila seleccionada del modelo de tabla
                    tablita.removeRow(fila);
                } else {
                    JOptionPane.showMessageDialog(null, "Seleccionar fila");
                }
            }
        });
    }

    // Método para obtener el panel de empleados
    public JPanel getPanel() {
        return empleadoPanel;
    }

    // Método main para ejecutar la aplicación
    public static void main(String[] args) {
        // Crear y configurar el frame
        JFrame frame = new JFrame("Empleado");
        frame.setContentPane(new Empleado().getPanel());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}

