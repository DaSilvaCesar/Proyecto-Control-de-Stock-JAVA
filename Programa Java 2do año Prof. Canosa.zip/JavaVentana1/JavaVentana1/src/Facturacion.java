import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Facturacion {
    private JTextField productoTxt;
    private JTextField empleadoTxt;
    private JTextField idClienteTxt;
    private JTextField cantidadTxt;
    private JTextField precioTxt;
    private JButton agregarButton;
    private JButton eliminarButton;
    private JTextField subtotalTxt;
    private JButton aplicarButton;
    private JTable table1;
    private JPanel facturacionPanel;
    private JLabel totalCambio;
    private JTextField textField1;
    private DefaultTableModel tabla1;
    private double total;
    private double subtotal;

    public Facturacion() {
        tabla1 = new DefaultTableModel();
        tabla1.addColumn("Producto");
        tabla1.addColumn("ID empleado");
        tabla1.addColumn("ID cliente");
        tabla1.addColumn("Cantidad");
        tabla1.addColumn("Precio");
        tabla1.addColumn("Subtotal");
        table1.setModel(tabla1);

        agregarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String idProd = productoTxt.getText();
                    int emple = Integer.parseInt(empleadoTxt.getText());
                    int clien = Integer.parseInt(idClienteTxt.getText());
                    int cant = Integer.parseInt(cantidadTxt.getText());
                    double prec = Double.parseDouble(precioTxt.getText());
                    subtotal = cant * prec;

                    total += subtotal;
                    subtotalTxt.setText(String.valueOf(total));

                    Object[] datos = new Object[]{idProd, emple, clien, cant, prec, subtotal};
                    tabla1.addRow(datos);

                    // Limpiar los campos de texto después de agregar el producto
                    productoTxt.setText("");
                    empleadoTxt.setText("");
                    idClienteTxt.setText("");
                    cantidadTxt.setText("");
                    precioTxt.setText("");

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(facturacionPanel, "Por favor, introduce datos válidos.", "Error", JOptionPane.ERROR_MESSAGE);
                }

            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int fila = table1.getSelectedRow();

                if (fila >= 0) { // Verificar que una fila esté seleccionada
                    double subtotal = Double.parseDouble(tabla1.getValueAt(fila, 5).toString());
                    total -= subtotal;
                    subtotalTxt.setText(""); // Limpiar subtotal
                    textField1.setText(""); // Limpiar descuento
                    totalCambio.setText(""); // Limpiar total
                    tabla1.removeRow(fila);
                } else {
                    JOptionPane.showMessageDialog(facturacionPanel, "Por favor, selecciona una fila para eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        aplicarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Aplicar descuento
                double descuento = 0.0;
                try {
                    descuento = Double.parseDouble(textField1.getText());
                    if (descuento < 0 || descuento > 100) {
                        throw new NumberFormatException();
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(facturacionPanel, "Por favor, introduce un descuento válido entre 0 y 100.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Aplicar el descuento al total
                total -= total * (descuento / 100);
                subtotalTxt.setText(String.valueOf(total));
                totalCambio.setText(String.valueOf(total)); // Actualizar el total
            }
        });
    }

    public JPanel getPanel() {
        return facturacionPanel;
    }
}




