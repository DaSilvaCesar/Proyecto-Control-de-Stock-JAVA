import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Menu1 {
    private JButton stockButton;
    private JButton clientesButton;
    private JButton proveedoresButton;
    private JButton empleadosButton;
    private JButton facturacionButton;
    private JPanel menu1Panel;

    public Menu1() {
        stockButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("Stock");
                frame.setContentPane(new Stock().getPanel());
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.setSize(600, 450); // Tamaño fijo
                frame.setResizable(false); // No permitir redimensionar
                frame.setLocationRelativeTo(null); // Centrar la ventana
                frame.setVisible(true);
            }
        });
        clientesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("Clientes");
                frame.setContentPane(new Cliente().getPanel());
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.setSize(550, 450); // Tamaño fijo
                frame.setResizable(false); // No permitir redimensionar
                frame.setLocationRelativeTo(null); // Centrar la ventana
                frame.setVisible(true);
            }
        });
        empleadosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("Empleados");
                frame.setContentPane(new Empleado().getPanel());
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.setSize(550, 450); // Tamaño fijo
                frame.setResizable(false); // No permitir redimensionar
                frame.setLocationRelativeTo(null); // Centrar la ventana
                frame.setVisible(true);
            }
        });
        proveedoresButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("Proveedores");
                frame.setContentPane(new Proveedor().getPanel());
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.setSize(550, 450); // Tamaño fijo
                frame.setResizable(false); // No permitir redimensionar
                frame.setLocationRelativeTo(null); // Centrar la ventana
                frame.setVisible(true);
            }
        });
        facturacionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("Facturacion");
                frame.setContentPane(new Facturacion().getPanel());
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.setSize(850, 500); // Tamaño fijo
                frame.setResizable(false); // No permitir redimensionar
                frame.setLocationRelativeTo(null); // Centrar la ventana
                frame.setVisible(true);
            }
        });
    }

    public JPanel getPanel() {
        return menu1Panel;
    }
}
