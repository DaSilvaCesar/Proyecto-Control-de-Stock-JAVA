import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Register {

    private JTextField txtNombre;
    private JTextField txtApellido;
    private JTextField txtDni;
    private JTextField txtSector;
    private JTextField txtLegajo;
    private JTextField txtDireccion;
    private JButton aceptarButton;
    private JButton cancelarButton;
    private JLabel regis;
    private JLabel nombre;
    private JLabel apellido;
    private JLabel dni;
    private JLabel sector;
    private JLabel legajo;
    private JLabel direccion;
    private JPanel registerPanel;

    public Register(JFrame parentFrame) {
        cancelarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Cerrar la ventana de registro y mostrar la ventana de login
                SwingUtilities.getWindowAncestor(registerPanel).dispose();
                parentFrame.setVisible(true);
            }
        });
    }

    public JPanel getPanel() {
        return registerPanel;
    }
}
