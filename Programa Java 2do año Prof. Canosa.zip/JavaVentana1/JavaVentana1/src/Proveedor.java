import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Proveedor {
    private JTextField textField1;  // Nombre Empresa
    private JTextField textField2;  // Dirección
    private JTextField textField3;  // CUIT
    private JTextField textField4;  // Teléfono
    private JPanel proveedoresPanel;
    private JButton registrarButton;
    private JButton eliminarButton;
    private JTable table1;
    private DefaultTableModel tablita;

    public Proveedor() {
        // Inicializar el modelo de tabla
        tablita = new DefaultTableModel();
        tablita.addColumn("Nombre Empresa");
        tablita.addColumn("Dirección");
        tablita.addColumn("CUIT");
        tablita.addColumn("Teléfono");

        // Configurar la tabla con el modelo
        table1.setModel(tablita);

        // Agregar listener al botón de registrar
        registrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obtener los valores de los campos de texto
                String nombreEmpresa = textField1.getText();
                String direccion = textField2.getText();
                String cuit = textField3.getText();
                String telefono = textField4.getText();

                // Agregar una nueva fila al modelo de tabla
                Object[] datos = new Object[]{nombreEmpresa, direccion, cuit, telefono};
                tablita.addRow(datos);

                // Limpiar los campos de texto después de registrar el proveedor
                textField1.setText("");
                textField2.setText("");
                textField3.setText("");
                textField4.setText("");
            }
        });

        // Agregar listener al botón de eliminar
        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obtener la fila seleccionada
                int fila = table1.getSelectedRow();
                if (fila >= 0) {
                    // Eliminar la fila seleccionada del modelo de tabla
                    tablita.removeRow(fila);
                } else {
                    JOptionPane.showMessageDialog(null, "Seleccionar fila");
                }
            }
        });
    }

    // Método para obtener el panel de proveedores
    public JPanel getPanel() {
        return proveedoresPanel;
    }

    // Método main para ejecutar la aplicación
    public static void main(String[] args) {
        // Crear y configurar el frame
        JFrame frame = new JFrame("Proveedor");
        frame.setContentPane(new Proveedor().getPanel());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}

