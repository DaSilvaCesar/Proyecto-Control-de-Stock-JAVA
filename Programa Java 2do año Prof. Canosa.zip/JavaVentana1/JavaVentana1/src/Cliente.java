import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Cliente {
    private JTextField textField1;  // DNI
    private JTextField textField2;  // Nombre
    private JTextField textField3;  // Apellido
    private JTextField textField4;  // Fecha de Nacimiento
    private JPanel clientePanel;
    private JButton registrarButton;
    private JButton eliminarButton;
    private JTable table1;
    private DefaultTableModel tablita;

    public Cliente() {
        tablita = new DefaultTableModel();
        tablita.addColumn("DNI");
        tablita.addColumn("Nombre");
        tablita.addColumn("Apellido");
        tablita.addColumn("Fecha de Nacimiento");
        table1.setModel(tablita);

        registrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String dni = textField1.getText();
                String nombre = textField2.getText();
                String apellido = textField3.getText();
                String fechaNacimiento = textField4.getText();

                Object[] datos = new Object[]{dni, nombre, apellido, fechaNacimiento};
                tablita.addRow(datos);

                // Limpia los campos de texto después de registrar el cliente
                textField1.setText("");
                textField2.setText("");
                textField3.setText("");
                textField4.setText("");
            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int fila = table1.getSelectedRow();
                if (fila >= 0) {
                    tablita.removeRow(fila);
                } else {
                    JOptionPane.showMessageDialog(null, "Seleccionar fila");
                }
            }
        });
    }

    public JPanel getPanel() {
        return clientePanel;
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Cliente");
        frame.setContentPane(new Cliente().getPanel());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}


