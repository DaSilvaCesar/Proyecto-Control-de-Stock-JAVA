import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login extends JFrame {
    private JTextField usuarioCampo;
    private JPasswordField contraseñaCampo;
    private JButton Iniciar;
    private JButton registrar;
    private JLabel contraseña;
    private JLabel usuario;
    private JLabel login;
    private JPanel loginPanel;

    public Login() {
        Iniciar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Bienvenido " + usuarioCampo.getText());
                JFrame frame = new JFrame("Menu");
                frame.setContentPane(new Menu1().getPanel());
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.setSize(600, 430); // Tamaño fijo
                frame.setResizable(false); // No permitir redimensionar
                frame.setLocationRelativeTo(null); // Centrar la ventana
                frame.setVisible(true);
            }
        });

        registrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("Registro");
                frame.setContentPane(new Register(Login.this).getPanel());
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.setSize(600, 450); // Tamaño fijo
                frame.setResizable(false); // No permitir redimensionar
                frame.setLocationRelativeTo(null); // Centrar la ventana
                frame.setVisible(true);
                // Ocultar la ventana de login
                Login.this.setVisible(false);
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Login");
        frame.setContentPane(new Login().loginPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setMinimumSize(new Dimension(550, 300));
        frame.setLocationRelativeTo(null);
        frame.pack();
        frame.setVisible(true);
    }
}

