import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Stock {
    private JTextField idProductoTxt;
    private JTextField precioTxt;
    private JTextField nombreTxt;
    private JTextField cantidadTxt;
    private JPanel stockPanel;
    private JButton eliminarBoton;
    private JButton ingresarBoton;
    private JTable table1;
    private DefaultTableModel tablita;

    public Stock(){
        tablita = new DefaultTableModel();
        tablita.addColumn("ID Producto");
        tablita.addColumn("precio");
        tablita.addColumn("Nombre");
        tablita.addColumn("Cantidad");
        table1.setModel(tablita);
        ingresarBoton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                    Integer idProd = Integer.parseInt(idProductoTxt.getText());
                    String nom = nombreTxt.getText();
                    Integer cant = Integer.parseInt(cantidadTxt.getText());
                    double prec = Double.parseDouble(precioTxt.getText());


                    Object[] datos = new Object[]{idProd,prec,nom,cant};
                    tablita.addRow(datos);

                    // Limpia los campos de texto después de agregar el producto

                    idProductoTxt.setText("");
                    nombreTxt.setText("");
                    cantidadTxt.setText("");
                    precioTxt.setText("");


            }
        });
        eliminarBoton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int fila= table1.getSelectedRow();
                if(fila>=0){
                    tablita.removeRow(fila);
                }else{
                    JOptionPane.showMessageDialog(null, "Seleccionar fila");
                }
            }
        });
    }
    public JPanel getPanel() {
        return stockPanel;
    }
}
